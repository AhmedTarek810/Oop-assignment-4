import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;

public class Main {
    public static void main(String[] args) {
        try (
                PrintWriter Creat = new PrintWriter(new FileOutputStream(new File("Heba.txt"), true));
        ) {
            for (int i = 0; i < 100; i++) {
                Creat.print((int)(Math.random() * 100) + " ");
            }
        }
        catch (FileNotFoundException e) {
            System.out.println("Cannot create the file.");

        }

    }
}