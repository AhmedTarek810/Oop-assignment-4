import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        String removeW = "";
        File file1 = new File("\"C:\\Users\\ahmed\\IdeaProjects\\Sheet5 - Q4\\java Exercise7 John filename.txt\"");
        try {
           Scanner input = new Scanner(file1);
           while (input.hasNextLine()){
               removeW=input.next();
               if (input.next("John") != null ){
                   removeW.replaceAll("John","");
            }
            }
       }
       catch (FileNotFoundException e) {
            System.out.println("File not found");
       }
    }
}