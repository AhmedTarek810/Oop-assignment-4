import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int count = 0;
        try{

            URL url = new URL("http://cs.armstrong.edu/liang/data/Lincoln.txt");
            Scanner input = new Scanner(url.openStream());
            while (input.hasNext()){
                String line = input.nextLine();
                count += line.length();
            }
        }
        catch (MalformedURLException ex){
            System.out.println("Invalid URL");
        }
        catch (IOException e){
            System.out.println("IO Errors");
        }
        System.out.println("The file size is " + count + " characters");
    }


}